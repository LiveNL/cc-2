begin
   d:=4;
   z:=1; 
   x:=0;
   y:=2;
   b:=2;
   while x > 0 do {
      z:= z * y;
      x:= x - 1;
   }
end