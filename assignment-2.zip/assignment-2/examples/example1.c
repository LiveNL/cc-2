begin
    a := 1;
    b := 2;
    if a == 1 then
        a := 2;
    else {
        a := a;
    }
end
