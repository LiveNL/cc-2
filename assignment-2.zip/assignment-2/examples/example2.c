begin
    a := 1;
    b := 2;
    c := 3;
    a := b;
    b := c;
    c := a;
end
