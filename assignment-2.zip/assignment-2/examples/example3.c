begin
    a := 5;
    while a > 0 do {
      a := a - 1;
   }
end
