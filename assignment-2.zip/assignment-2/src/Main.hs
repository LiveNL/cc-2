module Main where

import Lexer
import Parser

import System.Environment


main :: IO ()
main = undefined 



